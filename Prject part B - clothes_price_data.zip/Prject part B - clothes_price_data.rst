.. code:: ipython3

    import pandas as pd
    import seaborn as sb
    import math
    import matplotlib.pyplot as plt

.. code:: ipython3

    df= pd.read_csv(r'C:\Users\User\.jupyter\clothes_price_data.csv')
    df




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>ItemID</th>
          <th>ItemName</th>
          <th>Brand</th>
          <th>Category</th>
          <th>Size</th>
          <th>Price</th>
          <th>Unnamed: 6</th>
          <th>Unnamed: 7</th>
          <th>Unnamed: 8</th>
          <th>Unnamed: 9</th>
          <th>Unnamed: 10</th>
          <th>Unnamed: 11</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>1</td>
          <td>Jacket</td>
          <td>BrandB</td>
          <td>Outerwear</td>
          <td>M</td>
          <td>75.07</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
        </tr>
        <tr>
          <th>1</th>
          <td>2</td>
          <td>T-Shirt</td>
          <td>BrandE</td>
          <td>Footwear</td>
          <td>S</td>
          <td>45.61</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
        </tr>
        <tr>
          <th>2</th>
          <td>3</td>
          <td>Jeans</td>
          <td>BrandE</td>
          <td>Footwear</td>
          <td>S</td>
          <td>114.02</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
        </tr>
        <tr>
          <th>3</th>
          <td>4</td>
          <td>Shoes</td>
          <td>BrandD</td>
          <td>Footwear</td>
          <td>S</td>
          <td>52.76</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
        </tr>
        <tr>
          <th>4</th>
          <td>5</td>
          <td>Jeans</td>
          <td>BrandC</td>
          <td>Bottomwear</td>
          <td>S</td>
          <td>159.53</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
        </tr>
        <tr>
          <th>...</th>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
          <td>...</td>
        </tr>
        <tr>
          <th>495</th>
          <td>496</td>
          <td>Shoes</td>
          <td>BrandB</td>
          <td>Dresses</td>
          <td>XL</td>
          <td>166.42</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
        </tr>
        <tr>
          <th>496</th>
          <td>497</td>
          <td>Shoes</td>
          <td>BrandD</td>
          <td>Footwear</td>
          <td>M</td>
          <td>180.80</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
        </tr>
        <tr>
          <th>497</th>
          <td>498</td>
          <td>Jacket</td>
          <td>BrandD</td>
          <td>Outerwear</td>
          <td>XL</td>
          <td>48.89</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
        </tr>
        <tr>
          <th>498</th>
          <td>499</td>
          <td>Jeans</td>
          <td>BrandC</td>
          <td>Topwear</td>
          <td>XL</td>
          <td>75.65</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
        </tr>
        <tr>
          <th>499</th>
          <td>500</td>
          <td>T-Shirt</td>
          <td>BrandA</td>
          <td>Bottomwear</td>
          <td>L</td>
          <td>94.41</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
          <td>NaN</td>
        </tr>
      </tbody>
    </table>
    <p>500 rows × 12 columns</p>
    </div>



.. code:: ipython3

    # Shape - the number of the columns and the rows 
    print(df.shape)


.. parsed-literal::

    (500, 6)
    

.. code:: ipython3

    #Data Description
    # The file contains data for different clothing brands where each type of clothing is sorted by brand type, size, category, name and price, and the item number
    #In this work we will manipulate the data and draw conclusions such as: maximum price per item, minimum, average, sorting into groups and more

.. code:: ipython3

    #Displays general information aboute the data   
    print(df.info)


.. parsed-literal::

    <bound method DataFrame.info of      ItemID ItemName   Brand    Category Size   Price
    0         1   Jacket  BrandB   Outerwear    M   75.07
    1         2  T-Shirt  BrandE    Footwear    S   45.61
    2         3    Jeans  BrandE    Footwear    S  114.02
    3         4    Shoes  BrandD    Footwear    S   52.76
    4         5    Jeans  BrandC  Bottomwear    S  159.53
    ..      ...      ...     ...         ...  ...     ...
    495     496    Shoes  BrandB     Dresses   XL  166.42
    496     497    Shoes  BrandD    Footwear    M  180.80
    497     498   Jacket  BrandD   Outerwear   XL   48.89
    498     499    Jeans  BrandC     Topwear   XL   75.65
    499     500  T-Shirt  BrandA  Bottomwear    L   94.41
    
    [500 rows x 6 columns]>
    

.. code:: ipython3

    #remove duplicte
    df = df.drop_duplicates()

.. code:: ipython3

    # Shape - the number of the columns and the rows 
    print(df.shape)


.. parsed-literal::

    (500, 6)
    

.. code:: ipython3

    #Checks if there are Null cells 
    df.isnull().sum() 




.. parsed-literal::

    ItemID      0
    ItemName    0
    Brand       0
    Category    0
    Size        0
    Price       0
    dtype: int64



.. code:: ipython3

    #Values

.. code:: ipython3

    #max  Price 
    max_Price = df['Price'].max()
    print('The max price is:', max_Price)


.. parsed-literal::

    The max price: 199.47
    

.. code:: ipython3

    #min Price
    min_Price = df['Price'].min()
    print('The Min price is for all categories for all Categoreis :', min_Price)


.. parsed-literal::

    The Min price is: 10.39
    

.. code:: ipython3

    #avg
    avg_price = df['Price'].mean()
    print('The average price for all Cateforeis is: $avg_price:.2f')


.. parsed-literal::

    The average price is: $avg_price:.2f
    

.. code:: ipython3

    average_price_by_Category = df.groupby('Category')['Price'].mean().sort_values(ascending=False)
    print("Average price per Category:")
    print(average_price_by_Category)


.. parsed-literal::

    Average price per Category:
    Category
    Bottomwear    114.418100
    Footwear      112.866264
    Dresses       107.680103
    Outerwear     107.566789
    Topwear       107.209806
    Name: Price, dtype: float64
    

.. code:: ipython3

    # Max price per category

.. code:: ipython3

    max_price_by_Category = df.groupby('Category')['Price'].max().sort_values(ascending=False)
    print("max price per Category:")
    print(max_price_by_Category)


.. parsed-literal::

    max price per Category:
    Category
    Footwear      199.47
    Dresses       199.00
    Topwear       197.76
    Outerwear     197.14
    Bottomwear    196.19
    Name: Price, dtype: float64
    

.. code:: ipython3

    #Min price per category

.. code:: ipython3

    min_price_by_Category = df.groupby('Category')['Price'].min().sort_values(ascending=False)
    print("min price per Category:")
    print(min_price_by_Category)


.. parsed-literal::

    min price per Category:
    Category
    Outerwear     15.54
    Topwear       11.92
    Footwear      10.98
    Dresses       10.87
    Bottomwear    10.39
    Name: Price, dtype: float64
    

.. code:: ipython3

    unique_Brand = df['Brand'].unique() 
    num_Brand = len(unique_Brand)
    print("The amountof the different Brand of clusing :" ,num_Brand)
    print(f"The names are  : {', '.join(unique_Brand)}")


.. parsed-literal::

    The amountof the different Brand of clusing : 5
    The names are  : BrandB, BrandE, BrandD, BrandC, BrandA
    

.. code:: ipython3

    #Vizualiations

.. code:: ipython3

    import pandas as pd
    import matplotlib.pyplot as plt
    
    plt.figure(figsize=(10, 6))
    # Create column bar
    plt.bar(df['Brand'], df['Price'], color='lightgreen')
    
    #Create Title 
    plt.title('The price trend for each brand')
    
    # X axis definition
    plt.xlabel('Brand')
    
    #Y axis definition
    plt.ylabel('Price')
    
    plt.show()



.. image:: output_19_0.png


.. code:: ipython3

    import matplotlib.pyplot as plt
    import numpy as np
    
    # Creating serial numbers for the brands
    x = np.arange(len(df['Brand']))
    
    plt.figure(figsize=(10, 6))
    
    # Creating a bar graph
    plt.bar(x, df['Price'], color='lightgreen', alpha=0.7)
    
    # Adding a scatter graph  
    plt.scatter(x, df['Price'], color='darkgreen')
    
    # Calculation and drawing of the trend line
    z = np.polyfit(x, df['Price'], 1)
    p = np.poly1d(z)
    plt.plot(x, p(x), "r--", color='red')
    
    # Definition of titles and axes
    plt.title('The price trend for each brand')
    plt.xlabel('Brand')
    plt.ylabel('Price')
    
    #Setting the X-axis label
    plt.xticks(x, df['Brand'], rotation=45, ha='right')
    
    # הוספת מקרא
    plt.legend(['Trend Line', 'Price per Brand'])
    
    plt.tight_layout()
    plt.show()


.. parsed-literal::

    C:\Users\User\AppData\Local\Temp\ipykernel_11276\3771515008.py:18: UserWarning: color is redundantly defined by the 'color' keyword argument and the fmt string "r--" (-> color='r'). The keyword argument will take precedence.
      plt.plot(x, p(x), "r--", color='red')
    


.. image:: output_20_1.png


.. code:: ipython3

    import matplotlib.pyplot as plt
    import seaborn as sns
    import pandas as pd
    
    plt.figure(figsize=(12, 6))
    
    # Creating a penguin graph
    sns.violinplot(x='Brand', y='Price', data=df, palette='Set3')
    
    #Definition of titles and axes
    plt.title('Price Distribution for each Brand')
    plt.xlabel('Brand')
    plt.ylabel('Price')
    
    plt.xticks(rotation=45, ha='right')
    
    plt.tight_layout()
    plt.show()


.. parsed-literal::

    C:\Users\User\AppData\Local\Temp\ipykernel_11276\1554604595.py:8: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `x` variable to `hue` and set `legend=False` for the same effect.
    
      sns.violinplot(x='Brand', y='Price', data=df, palette='Set3')
    


.. image:: output_21_1.png


.. code:: ipython3

    import matplotlib.pyplot as plt
    import pandas as pd
    
     # Calculation of the sum of prices for each brand
    brand_totals = df.groupby('Brand')['Price'].sum()
    
    plt.figure(figsize=(8, 8))
    
    # Creating a pie chart
    plt.pie(brand_totals.values, labels=brand_totals.index, autopct='%1.1f%%', startangle=90)
    
    # Title
    plt.title('Market Share by Brand (Based on Total Price)', fontsize=16)
    
    
    plt.axis('equal')   
    plt.tight_layout()
    plt.show()



.. image:: output_22_0.png


